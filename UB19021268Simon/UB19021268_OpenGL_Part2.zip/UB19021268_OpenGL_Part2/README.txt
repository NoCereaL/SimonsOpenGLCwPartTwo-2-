*****READ ME!*****

GAME RULES

Destroy all the blocks that are generated to get a score

MOVEMENT

WASD
Left Click to Shoot
Face the object you want to destroy!